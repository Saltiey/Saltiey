# random-word-api
scala rest api to serve random words

It's alive at https://random-word-api.herokuapp.com/

To run, `sbt run`

Uses Cask
